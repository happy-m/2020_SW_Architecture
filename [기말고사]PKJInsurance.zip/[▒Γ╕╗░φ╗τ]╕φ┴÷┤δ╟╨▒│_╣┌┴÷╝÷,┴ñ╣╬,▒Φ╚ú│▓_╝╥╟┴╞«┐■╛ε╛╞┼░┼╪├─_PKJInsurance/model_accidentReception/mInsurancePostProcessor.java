package model_accidentReception;

import model_employee.mEmployee;

public class mInsurancePostProcessor extends mEmployee {

	private int insurancePostProcessorID;

	public mInsurancePostProcessor() {

	}

	public int getInsurancePostProcessorID() {
		return insurancePostProcessorID;
	}

	public void setInsurancePostProcessorID(int insurancePostProcessorID) {
		this.insurancePostProcessorID = insurancePostProcessorID;
	}

}